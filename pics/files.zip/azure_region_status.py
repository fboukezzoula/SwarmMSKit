#!/usr/bin/env python3
"""
azure_region_status.py — Lit https://azure.microsoft.com/.../products-by-region/table
(page 100% JavaScript, sans API publique connue) via un navigateur headless
et renvoie le statut d'un Product (ou Product/SKU) pour une Region donnée :
  Generally Available | In Public Preview | Retiring | Not available

Nécessite Playwright (installé automatiquement par le wrapper bash).
"""

import argparse
import re
import sys
import time

from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout

DEFAULT_URL = "https://azure.microsoft.com/fr-fr/explore/global-infrastructure/products-by-region/table"

STATUS_MAP = {
    "generally available": "Generally Available",
    "disponibilité générale": "Generally Available",
    "disponibilite generale": "Generally Available",
    "ga": "Generally Available",
    "in public preview": "In Public Preview",
    "en préversion publique": "In Public Preview",
    "en preversion publique": "In Public Preview",
    "preview": "In Public Preview",
    "préversion": "In Public Preview",
    "retiring": "Retiring",
    "en cours de retrait": "Retiring",
    "retrait": "Retiring",
    "not available": "Not available",
    "non disponible": "Not available",
}


def normalize(s: str) -> str:
    """Minuscule, sans accents/espaces/ponctuation, pour comparaison robuste."""
    s = s.lower()
    s = (s.replace("é", "e").replace("è", "e").replace("ê", "e")
           .replace("à", "a").replace("ù", "u").replace("ç", "c")
           .replace("î", "i").replace("ô", "o"))
    return re.sub(r"[^a-z0-9]+", "", s)


def map_status(raw: str) -> str:
    n = raw.strip().lower()
    for key, val in STATUS_MAP.items():
        if key in n:
            return val
    return raw.strip() or "Unknown"


def dump_debug(page, prefix="/tmp/azure-region-status-debug"):
    try:
        page.screenshot(path=f"{prefix}.png", full_page=True)
        with open(f"{prefix}.html", "w", encoding="utf-8") as f:
            f.write(page.content())
        print(f"[debug] Capture et HTML enregistrés dans {prefix}.png / {prefix}.html", file=sys.stderr)
    except Exception as e:
        print(f"[debug] Échec de la sauvegarde de debug : {e}", file=sys.stderr)


def try_click_any(page, patterns, timeout=3000):
    """Essaie de cliquer le premier élément dont le texte matche l'un des patterns."""
    for pat in patterns:
        try:
            loc = page.get_by_text(re.compile(pat, re.I)).first
            loc.click(timeout=timeout)
            return True
        except Exception:
            continue
    return False


def select_region(page, region: str, timeout: int, debug: bool) -> bool:
    """Ouvre le sélecteur de régions et coche la région demandée."""
    # Ouvre le panneau de sélection (le libellé exact peut varier selon la locale)
    try_click_any(page, [
        r"select a geograph", r"sélectionner une géograph", r"select region",
        r"sélectionner.*région", r"select a region",
    ], timeout=5000)

    page.wait_for_timeout(500)

    target = normalize(region)
    # Cherche un libellé (checkbox/label/bouton) dont le texte normalisé contient la région
    candidates = page.locator("label, li, button, span, div[role='checkbox'], input[type='checkbox'] + label")
    count = candidates.count()
    clicked = False
    for i in range(min(count, 4000)):
        try:
            el = candidates.nth(i)
            txt = el.inner_text(timeout=200)
        except Exception:
            continue
        if not txt or len(txt) > 80:
            continue
        if target and target in normalize(txt):
            try:
                el.click(timeout=1500)
                clicked = True
                break
            except Exception:
                # Peut-être une checkbox associée juste avant/après
                try:
                    el.locator("xpath=preceding-sibling::input[@type='checkbox'][1]").click(timeout=1000)
                    clicked = True
                    break
                except Exception:
                    continue

    if not clicked and debug:
        print(f"[debug] Région « {region} » non trouvée dans le sélecteur.", file=sys.stderr)

    # Valide la sélection si un bouton Apply/Appliquer/Voir existe
    try_click_any(page, [
        r"^apply$", r"^appliquer$", r"^ok$", r"^voir les produits$",
        r"^view products$", r"^valider$",
    ], timeout=2000)

    page.wait_for_timeout(800)
    return clicked


def select_product(page, product: str, debug: bool) -> bool:
    """Renseigne le champ de recherche produit."""
    box = None
    for ph in [r"product", r"produit", r"search", r"recherch"]:
        try:
            cand = page.get_by_placeholder(re.compile(ph, re.I)).first
            cand.wait_for(timeout=1500)
            box = cand
            break
        except Exception:
            continue

    if box is None:
        if debug:
            print("[debug] Champ de recherche produit introuvable, tentative sans filtre.", file=sys.stderr)
        return False

    try:
        box.click()
        box.fill(product)
        page.wait_for_timeout(1200)
        # Si une liste de suggestions apparaît, clique la première correspondance
        try:
            sugg = page.get_by_text(re.compile(re.escape(product), re.I)).first
            sugg.click(timeout=1500)
            page.wait_for_timeout(800)
        except Exception:
            pass
        return True
    except Exception as e:
        if debug:
            print(f"[debug] Échec de la saisie produit : {e}", file=sys.stderr)
        return False


def find_status(page, product: str, sku: str, region: str, debug: bool):
    page.wait_for_selector("table", timeout=20000)

    header_cells = page.query_selector_all("table th")
    col_index = None
    region_n = normalize(region)
    for i, th in enumerate(header_cells):
        if region_n and region_n in normalize(th.inner_text()):
            col_index = i
            break

    if col_index is None:
        if debug:
            headers = [th.inner_text() for th in header_cells]
            print(f"[debug] Colonnes disponibles : {headers}", file=sys.stderr)
        return None, "Colonne région introuvable dans l'en-tête du tableau."

    rows = page.query_selector_all("table tbody tr")
    product_n = normalize(product)
    sku_n = normalize(sku) if sku else None

    target_row = None
    for row in rows:
        text = row.inner_text()
        tn = normalize(text)
        if product_n in tn and (sku_n is None or sku_n in tn):
            target_row = row
            break

    if target_row is None and sku_n:
        # Repli : essaie d'abord le produit seul, la ligne pourra être développée
        for row in rows:
            text = row.inner_text()
            if product_n in normalize(text):
                try:
                    row.query_selector("button, [role='button']").click(timeout=1000)
                    page.wait_for_timeout(500)
                except Exception:
                    pass
                if sku_n in normalize(row.inner_text()):
                    target_row = row
                    break

    if target_row is None:
        return None, f"Produit « {product} » introuvable dans le tableau."

    cells = target_row.query_selector_all("td")
    if col_index >= len(cells):
        return None, "Cellule correspondant à la région introuvable sur cette ligne."

    cell = cells[col_index]
    status_el = cell.query_selector("[title], [aria-label]")
    raw = None
    if status_el:
        raw = status_el.get_attribute("title") or status_el.get_attribute("aria-label")
    if not raw:
        raw = cell.inner_text()

    return map_status(raw or ""), None


def main():
    ap = argparse.ArgumentParser(description="Statut d'un produit Azure dans une région, via la page Products by Region.")
    ap.add_argument("product", help="Nom du produit, ou 'Product/SKU'")
    ap.add_argument("region", help="Nom de région (nom Azure CLI type 'westeurope' ou nom affiché 'West Europe')")
    ap.add_argument("--url", default=DEFAULT_URL, help="URL de la page (défaut: version fr-fr)")
    ap.add_argument("--timeout", type=int, default=45000, help="Timeout en ms")
    ap.add_argument("--debug", action="store_true", help="Sauvegarde capture d'écran + HTML en cas d'échec")
    args = ap.parse_args()

    if "/" in args.product:
        product, sku = args.product.split("/", 1)
    else:
        product, sku = args.product, None

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page()
        try:
            page.goto(args.url, wait_until="networkidle", timeout=args.timeout)
        except PWTimeout:
            page.goto(args.url, wait_until="domcontentloaded", timeout=args.timeout)

        select_region(page, args.region, args.timeout, args.debug)
        select_product(page, product, args.debug)

        status, err = find_status(page, product, sku, args.region, args.debug)

        if err or status is None:
            print(f"Erreur : {err}", file=sys.stderr)
            if args.debug:
                dump_debug(page)
            browser.close()
            sys.exit(1)

        browser.close()
        print(status)


if __name__ == "__main__":
    main()
